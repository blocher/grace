<?php

/**
 * The exception thrown when an engine is not set..
 *
 * @author     Time.ly Network Inc.
 * @since      2.0
 *
 * @package    AI1EC
 * @subpackage AI1EC.Controller.Exception
 */
class Ai1ec_Engine_Not_Set_Exception extends Ai1ec_Exception {
}